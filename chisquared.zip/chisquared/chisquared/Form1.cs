﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chisquared
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> actual = new List<double>();
            List<double> observed = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                actual.Add(double.Parse(s));
            }foreach(string s in textBox2.Text.Split(","))
            {
                observed.Add(double.Parse(s));
            }
            double x = actual.Zip(observed, (o, e) => Math.Pow(o - e, 2) / e).Sum();
            MessageBox.Show("" + x);
        }
    }
}
